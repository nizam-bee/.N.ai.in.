
const express = require("express");
const fetch = require("node-fetch");
const app = express();
require("dotenv").config();

app.use(express.static("public"));

app.get("/api/search", async (req, res) => {
  const q = req.query.q;
  try {
    const completion = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: "gpt-3.5-turbo",
        messages: [{ role: "user", content: q }],
      }),
    });
    const json = await completion.json();
    res.json({ answer: json.choices[0].message.content });
  } catch (err) {
    res.status(500).json({ error: "AI search failed." });
  }
});

app.listen(3000, () => console.log("n.ai.in running on port 3000"));
