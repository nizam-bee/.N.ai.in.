
async function search() {
  const query = document.getElementById("query").value;
  document.getElementById("summary").innerHTML = "Searching...";
  const response = await fetch("https://acrnoudgoukyfytxnffs.supabase.co/functions/v1/ai-search", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ query })
  });
  const result = await response.json();
  document.getElementById("summary").innerHTML = result.answer || "No answer returned.";
}
